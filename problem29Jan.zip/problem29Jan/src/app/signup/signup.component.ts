import { Component, OnInit } from '@angular/core';
import { SignUpServiceService } from '../sign-up-service.service';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html'
})
export class SignupComponent implements OnInit {
    // declaring variables for getting data from SignUp UI
    _firstname: string;
    _lastname: string;
    _username: string;
    _password: string;

  constructor(private signupServ: SignUpServiceService) {
      // initialize variable for using them later
      this._firstname = '';
      this._lastname = '';
      this._username = '';
      this._password = '';

   }

  ngOnInit() {
  }

  // this function will be called on submit of form from UI
  signUpService(): void {

  }

}
