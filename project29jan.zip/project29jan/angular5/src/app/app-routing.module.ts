import { NgModule, ModuleWithProviders } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SignupComponent } from './user/signup/signup.component';
import { LoginComponent } from './user/login/login.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { UserComponent } from './user/user.component';

const routes: Routes = [
  // {path: 'signup', component: SignupComponent},
  {path: 'login', component: LoginComponent},
  {path: ' ', component: DashboardComponent},
  {path: 'signup', component: UserComponent,
      children: [
          {path: '', component: SignupComponent}
      ]
  },
  {
    path: '', redirectTo: 'login', pathMatch: 'full'
  }

];

export const routing: ModuleWithProviders = RouterModule.forRoot(routes);


@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
