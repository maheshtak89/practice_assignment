 //1.
 var http = require('http');
 var emp = [];

 //2.
 var extServerOptions = {
     host:'localhost',
     port:'4050',
     path:'http://apiapptrainingservice.azurewebsites.net/api/Productses.net/api/Products',
     method:'GET'
 }

 //3.
 function get(){
     http.request(extServerOptions, function(res){
        res.setEncoding('utf8');
        res.on('data', function(data){
            emp = JSON.parse(data);
            emp.foreach(function(e){
                console.log(e.EmpNo+"\t"+e.EmpName+"\t"+e.Salary+"\t"+e.DeptName+"\t"+e.Designation)
            });//foreach
        })//res.on
     }).end();//http.request
 }//get()

 get();

 console.log("Doing post operation");

 //4.
 var employee = JSON.stringify({
     'EmpName':"Mahesh",
     'Salary':35000,
     'DeptName':'Developer',
     'Designation':'Fulstack Developer'
 });

 //5.
 var extServerOptionsPost = {
    host:'apiapptrainingservice.azurewebsites.net/api/Productses.net', 
    path:'/api/EmployeeInfoAPI',
    method:'POST',
    headers:{
        'Content-Type':'application/json'
    }
};


//7. 
var requestPost = http.request(extServerOptionsPost, function(res){
    console.log("Response code :",res.statusCode);
    res.on('data',function(data){
        console.log('Posting result');
        process.stdout.write(data);
        console.log(`\n\n Post operation Completed`);
    });
});

//8. 
    requestPost.write(employee);
    requestPost.end();
    requestPost.on('error', function(e){
        console.log(e);
    });