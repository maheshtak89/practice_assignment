import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, Router } from '@angular/router';
import { Observable } from 'rxjs';

@Injectable()
export class AppGuardService implements CanActivate {

    constructor(private _router: Router){}

    canActivate(
        route: ActivatedRouteSnapshot,
        state: RouterStateSnapshot
    ): boolean {
        console.log("CanActivate()")

        //return true
        alert(" You are not allowed to view this Page, \n Your navigating to Erro Component..");
        this._router.navigate(['error']);
        return false;
    }
}
