import { RouterModule, Routes, ActivatedRoute, ROUTES } from "@angular/router";
import { ModuleWithProviders } from "@angular/core";

import { HomeComponent } from "./app.home.component";
import { AboutComponent } from "./app.about.component";
import { ContactComponent } from "./app.contact.component";
import { ProductComponent } from "../productcomponent/app.product.component";
import { CategoryComponent } from "../../MultiComponentCOmmunication/app.category.component";
import { ItemList } from "./../../MultiCompCommunicationInputAndOutput/app.Itemlist.component";
import { AppGuardService } from "../../services/app.test.guard.service";
import { ErrorCOmponent } from "./app.error.component";

// we r going to add all route path and their components here in this files only and we can register this route file in NgModule, so it will available globally when app is loaded
// define route table
// const routes: Routes = [
//     {path: " ", component:  HomeComponent},
//     {path: 'about/:id', component: AboutComponent},
//     {path: 'contact', component: ContactComponent,
//         children: [
//             // { path:"product", component: CategoryComponent },
//             { path:"product", component: ItemList}
//         ]
//     }
// ];

const routes: Routes = [
    {path: "home", component:  HomeComponent},
    {path: 'about', component: AboutComponent},
    // here contact is RouteGuard
    {path: 'contact', component: ContactComponent, canActivate: [AppGuardService]},
    {path: '', redirectTo: 'home', pathMatch:"full"},
    {path: 'error', component: ErrorCOmponent},
    {path: 'error/home', component: HomeComponent}
];

//register the route table for Route of the current angular app
// when "routing" is provided to "imports" of NgModule, this will load RouterModule with Route Table.
export const routing: ModuleWithProviders = RouterModule.forRoot(routes); 
