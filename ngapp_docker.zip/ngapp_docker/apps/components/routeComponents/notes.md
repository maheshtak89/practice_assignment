**Routing**
- Single Page App
- Initialize Routing Environment    
    - @angular/router
        - RouterModule => Its manage RouteTable for the "current NgModule" aka Angular app.
        - Routes => represent routeTable, where each entry is Route.
                    Route is JSON object that contains the 'path' property aka template for URI.
                    The 'component' property, accepts ng component.
                    The 'childern' property used to contain 'Child-Routes' aka Sub-Routes.
                    The 'Redirect' property, if no math found for component then redirect to other (default) component.
        - Router Class => - navigate([<ROUTE URI's>]) 
        - ActivatedRoute => Currently loaded route expression.
                            The service object that keeps track of data used across routing.
        - The [routerLink], the attribute directive generally used for <a> tag to define and eecute Routing.
        - The <router-outlet></router-outlet>, the component where akk route views will be injected (showed).
        - The "moduleWithProviders" class from @angular/core to load the route table from RouteModule in imports array of NgModule.

        - Angular routing with guard
            - CanActivate => It descides if a route can be activated. If user not authorised navigate page to target component.
            - CanDeactivate =>
            - Resolve =>
            - CanLoad =>
            - CanActivatedChild =>