import {Component} from "@angular/core";

@Component({
    selector : "app-simple-component",
    template : `
    <h2> Hi I am First Angular COmponent....!!!@@@ </h2>
    <div class="container">
        <strong>{{ message }}</strong>
    </div>
    <br/>
    <div> {{10+20}} </div>
    <br/>
    <input type="text" class="form-control" [value] = "message"/> 
    <br/>
    <a href="url" >DevCurrey</a>
    <br/>
    <input type="button" class="btn btn-success" value="click me" (click)="print();"/>
    <br/>
    <input type="text" class="form-control" [(ngModel)]="fullName"/>  <br/>
    <input type="text" class="form-control" [(ngModel)]="fullName"/>  <br/>
    <input type="text" class="form-control" [(ngModel)]="fullName"/>  <br/>
    <h2> Calculator </h2>
    <div class="container">
        <input type="number" [(ngModel)]="firstValue"/><br/>
        <input type="number" [(ngModel)]="secondValue"/><br/>
        <input type="number" [(ngModel)]="actualOutput"disabled="true"/><br/>
        <input type="button" class="btn btn-success" value="Add" (click)="Add();"/>
        <input type="button" class="btn btn-success" value="Sub" (click)="Sub();"/>
    </div>
    `
})
export class SimpleComponent {
    message: string;
    name:string;
    url: string;
    fullName: string;
    firstValue: number;
    secondValue: number;
    actualOutput: number;

    constructor(){
        this.message = "Hello Angular 7..!!";
        this.name = "James Bond"
        this.url = "http://www.devcurry.com";
    }
    print() : void {
        this.message = "Hey Button is clicked...";
    }
    Add() : void{
        this.actualOutput = this.firstValue + this.secondValue;
    }
    Sub() : void{
        this.actualOutput = this.firstValue - this.secondValue;
    }
}