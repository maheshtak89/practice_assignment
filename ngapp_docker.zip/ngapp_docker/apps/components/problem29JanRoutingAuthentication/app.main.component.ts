import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'app-dashboard-component',
    template: `
        <h1> Welcome to DashBoard </h1>
        <br/>

        <div class="container">
            <table border="2">
                <tr>
                    <th>
                        <a [routerLink]="['register']"> New Registration </a>
                    </th>
                    <th>
                        <a [routerLink]="['login']"> Login here </a>
                    </th>
                </tr>
            </table>
        </div>
        <router-outlet></router-outlet>

    `
})
export class DashBoardComponent implements OnInit {
    constructor() { }

    ngOnInit(): void { }
}
