var Products = [
    {"id":101,"name":"Sanjay"},
    {"id":102,"name":"Lakhan"},
    {"id":103,"name":"Bharat"},
    {"id":104,"name":"Mangesh"},
    {"id":105,"name":"Rakesh"}
]

module.exports = {
    //get
    getData:function(){
        return Products;
    },
    //getById
    getById:function(id){

        return Products.filter((prod)=>{
            return prod.id == id;
        });
    },
    //post
    addData:function(prod){
        Products.push(prod);
         return Products
    },
    //put()
    //updating data based on ID and passed body
    updateData:function(prod, id){
        Products.forEach(element => {
            if(element.id == id){
                element.id = id;
                element.name = prod.name;
            }
        });
        return Products;
    },
    //delete()
    //this method will remove record from collection and return remain element of collection
    deleteData:function(id){
       var index;
       var flag =false;

        var dat = Products.find(function(item,i){     
            if(item.id == id){
                index = i;
                flag =true;
                return index;
            }

       });

       //console.log('Index'+index);
       if(flag == true){
          Products.splice(index,  1);
           return Products;
       }
       return Products;
       
    }


}