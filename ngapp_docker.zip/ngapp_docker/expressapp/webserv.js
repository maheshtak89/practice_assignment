var express = require("express");
var path = require("path");
var bodyParser = require("body-parser");
var mongoose = require("mongoose");
var jwt = require('jsonwebtoken');
mongoose.Promise = global.Promise;
var cors = require("cors");
var instance = express();
var router = express.Router();
instance.use(router);
instance.use(bodyParser.urlencoded({ extended: false }));
instance.use(bodyParser.json());
instance.use(cors());

mongoose.connect(
  "mongodb://localhost/ProductsAppDB",
  { useNewUrlParser: true }
);

var dbConnect = mongoose.connection;

if (!dbConnect) {
  console.log("Sorry Connection is not established");
  return;
}

var userSchema = mongoose.Schema({
 username: String,
 password: String
});

var userModel = mongoose.model("userModel", userSchema, "userModel");

instance.post("/api/products/create", function(request, response) {

    var user = {
    username: request.body.username,
    password: request.body.password
  };
  // pass the parsed object to "create()" method
  userModel.create(user, function(err, res) {
    if (err) {
      response.statusCode = 500;
      response.send(err);
    }
    response.send({ status: 200, data: res });
  });
});

var jwtSettings = {
  jwtSecret: "dbcsbiobc0708hdfcyesbombob"
};

instance.set("jwtSecret", jwtSettings.jwtSecret );

var tokenStore = "";
// authenticate user

instance.post("/api/user/auth", function(request, response){
  var user = {
    username: request.body.username,
    password: request.body.password
  };
  console.log(`Authenticate user :${JSON.stringify(user)}`);
  
  userModel.findOne({ username: request.body.username}, function(err, usr){
    if(err){
      console.log("Some error occured");
    }

    // if user not found
    if(!usr){
      response.send({
          statusCode:404,
          message: " Sorry! User not exist..",
        })
      console.log("USer not exist")
    }else if(usr){

        // user is available but password not matched

        // respond error

        console.log("In else if"+JSON.stringify(usr));

        if(usr.password != user.password){
          response.send({
            statusCode: 404,
            message: "Sorry ! Username & password Not matched .."
          });
          console.log("uname pwd not matched..")
        }else{
          console.log("Success....")
          // sign in user and generate Token
          var token = jwt.sign({usr}, instance.get("jwtSecret"),{
            expiresIn: 3600
          });
          //save token globally
          tokenStore = token;
          response.send({
            authenticated : true,
            message: "Login Success !",
            token: token
          });
        }
    }
  })
});

// instance.get("/api/products/:id", function(request, response) {
//   // use "params" property of request object to read
//   // url parameter
//   var id = request.params.id;
//   console.log("Received id =" + id);
//   var record = dataModel.getData().filter(function(v, idx) {
//     return v.id == id;
//   });
//   response.send(JSON.stringify(record));
// });

// instance.put("/api/products/:id", function(request, response) {
//   // read the request id parameter
//   // read the body
//   // update matched record from array
//   // respond array
// });

// instance.delete("/api/products/:id", function(request, response) {
//   // read the request id parameter
//   // delete matched record array
//   // respond array
// });

var productSchema = mongoose.Schema({
  ProductId: Number,
  ProductName: String,
  CategoryName: String,
  Manufacturer: String,
  Price: Number
})

var productModele = mongoose.model("Products", productSchema, "Products");

// verify the token and provide access
router.get("/api/products", function(request, response){
    // read request hear containes bearer token<space><token>
    var tokenReceived = request.headers.authorization.split(" ")[1];
    //verify the token
    jwt.verify(tokenReceived, instance.get("jwtSecret"), function(err, decoded){
        console.log("In verify..");
        if(err){
          console.log("Some error occurred ...");
          response.send({
            success: false, message: "Token verification failed !"
          })
        }else{
          console.log("Auth success");
          request.decoded = decoded;
          productModele.find().exec(function(err, res){
            if(err){
              console.log("Error while gfetching products");
              response.statusCode = 500;
              response.send({status: response.statusCode, error: err });
            }
            response.send({status: 200, data: res});
          })
        }
    })
})//get

instance.post("api/products/")

// 6. start listening
instance.listen(4070, function() {
  console.log("started listening on port 4070");
})