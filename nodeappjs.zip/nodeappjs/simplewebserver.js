var http = require('http');


var data = [
    {
    id:101, name:"A",
    id:102, name:"B",
    id:103, name:"C",
    }
]
//1. create server

var server = http.createServer(function(request, response){

    //response.on(); ///it indicates I got a request and I am processing this request
    
    // response.writeHead(200,{'Content-Type':'text/html'});
    // response.write("Hello World");

    response.writeHead(200,{"Content-Type":"application/json"});    // we are restricting here for data formate JSON
    response.write(JSON.stringify(data));
    response.end();
});

//2. listen on port
server.listen(4050);
console.log('server started on port 4050');
