// module.exports = {
//     add: function(x,y){
//         return parseInt(x) + parseInt(y);
//     },
//     multi:function(x,y){
//         return parseInt(x) * parseInt(y);
//     }
// }

module.exports = {
    var file =[
        ""
    ];
}