console.log("Node.js");

var Employee = {
    EmpNo : 101, 
    EmpName : "Mahesh"
};

console.log(JSON.stringify(Employee));


function add(x,y){
    var res = parseInt(x) + parseInt(y);
    console.log("Addition of "+x+" and "+y+" is : "+res);
}

add(4,5);