import { PagesLogic } from "./pagesLogic";

var http = require('http');

var server = http.createServer(request, response);

var url = request.url();

server.listen(4065);

PagesLogic.callPage(request, response);

console.log("server started...");