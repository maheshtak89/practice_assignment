//this is json object, also known as literal
var product = {
    prodcutID: 101,
    productName: "Laptop"
};
//1. JSON serialization aka string parsing for JSON
console.log(JSON.stringify(product));
//2. Getting length of all keys of JSON object
var info = Object.keys(product).length;
console.log("Length of JSON data :" + info);
//3. Read all property names
for (var p in Object.keys(product)) {
    console.log(p);
}
//4. get the name of property
for (var _i = 0, _a = Object.keys(product); _i < _a.length; _i++) {
    var pname = _a[_i];
    console.log(pname);
}
