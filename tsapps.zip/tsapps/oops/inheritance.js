var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var Product = /** @class */ (function () {
    function Product(prodId, prodName) {
        this.prodId = prodId;
        this.prodName = prodName;
    }
    return Product;
}());
var ProductLogic = /** @class */ (function () {
    function ProductLogic() {
        this.product = new Product(0, "");
        this.products = new Array();
        this.products.push(new Product(101, "p1"));
        this.products.push(new Product(102, "p2"));
    }
    //getter method
    ProductLogic.prototype.getProducts = function () {
        return this.products;
    };
    //setter method
    ProductLogic.prototype.saveProduct = function (p) {
        this.products.push(p);
        return this.products;
    };
    return ProductLogic;
}());
//another class
var ProductOperations = /** @class */ (function (_super) {
    __extends(ProductOperations, _super);
    function ProductOperations() {
        return _super.call(this) || this;
    }
    //this method will search Products by ID
    ProductOperations.prototype.getProductById = function (id) {
        //write logic to search product
        return new Product(0, "----");
    };
    ProductOperations.prototype.getProductByCategory = function (cat) {
        //logic
        return this.products;
    };
    return ProductOperations;
}(ProductLogic));
var Presenter = /** @class */ (function () {
    function Presenter() {
    }
    Presenter.prototype.generateTable = function () {
        var Products = [
            { ProdId: 101, ProdName: "P1" },
            { ProdId: 102, ProdName: "P2" }
        ];
        var table = "<center><table border='2' cellspacing='2' cellpadding='2' align='center'><tr><td>ProductID</td><td>ProductName</td></tr>";
        for (var _i = 0, Products_1 = Products; _i < Products_1.length; _i++) {
            var p = Products_1[_i];
            table += "<tr align='center'><td>" + p.ProdId + "</td><td>" + p.ProdName + "</td></tr>";
        }
        table += "</table></center>";
        return table;
    };
    return Presenter;
}());
var prdOperation = new ProductOperations();
console.log(JSON.stringify(prdOperation.getProducts()));
var prd = new Product(103, "P3");
console.log(JSON.stringify(prdOperation.saveProduct(prd)));
