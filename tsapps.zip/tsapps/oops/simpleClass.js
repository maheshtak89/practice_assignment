var MathClass = /** @class */ (function () {
    //here constructor keyword used to write constrcutor
    function MathClass(x, y) {
        this.x = x;
        this.y = y;
        // private x:number = 0;
        // private y:number = 0;
        this.z = 0;
        // this.x= x;
        // this.y= y; 
    }
    //add() method
    MathClass.prototype.add = function () {
        this.z = this.x + this.y;
        return this.z;
    };
    //sub() method
    MathClass.prototype.sub = function () {
        this.z = this.x - this.y;
        return this.z;
    };
    return MathClass;
}());
//create object of MathClass with 2 arguments
var mObj = new MathClass(20, 30);
console.log("Add = " + mObj.add());
console.log("Add = " + mObj.sub());
