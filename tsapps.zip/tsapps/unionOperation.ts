function unionTypeOperation(val:number|string){
    if(typeof val === "number"){
        console.log("square : "+ val*val);
    }
    if(typeof val === "string"){
        console.log("Upper case : "+val.toUpperCase());
    }
}

unionTypeOperation(10);
unionTypeOperation("Mahesh");
