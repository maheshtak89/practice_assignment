//this is class ItemOperation
var ItemOperation = /** @class */ (function () {
    function ItemOperation() {
    }
    //function for adding items
    ItemOperation.prototype.addItems = function (pId, pName, pStatus) {
        //here we added user information is JSON object, next we have to store this object in Array
        var newItem = {
            id: pId,
            title: pName,
            completed: pStatus
        };
        //here stor  perticular JSON object in Array
        productList.push(newItem);
        return this.generateHtmlTable();
    }; //end of function
    //here is a function generateHtmlTable for creating table dynamically
    ItemOperation.prototype.generateHtmlTable = function () {
        var table = "<table><tr><td>Item ID </td><td> Title </td><td>Status</td></tr>";
        for (var _i = 0, productList_1 = productList; _i < productList_1.length; _i++) {
            var ele = productList_1[_i];
            table += "<tr><td>" + ele.id + "</td><td>" + ele.title + "</td><td>" + ele.completed + "</td></tr>";
        }
        table += '</table>';
        return table;
    };
    return ItemOperation;
}());
//create a list here for adding items
var productList = [
    {
        "id": 101,
        "title": "Mobile",
        "completed": "true"
    },
    {
        "id": 102,
        "title": "Refrigerator",
        "completed": "false"
    }
];
