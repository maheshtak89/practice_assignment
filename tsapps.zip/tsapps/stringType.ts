//variable name must start from lower case
//use camel-case fpr multi word varoable name
let firstName: string = "Mahesh";
let middleName: string = "Ravindra";
let lastName: string = "Tak";

//1. concatinate using old JS style (ES3 to 5)
let fullNameOld = firstName +" "+  middleName +" "+ lastName;
console.log("Full Name with old style : "+fullNameOld);

let fullNameWithNewTemplate = '${firstName}${middleName}${lastName}';
console.log('with Template string ${fullNameWithNewTemplate}');

