let myName : Array<string>;
myName = new Array<string>();

myName.push("sanjay");
myName.push("Deepak");
myName.push("Rajat");
myName.push("Bharat");

//simple array iteration
myName.forEach(printValues);

function printValues(val:string,idx:number){
    console.log(`Data at ${idx} is ${val}`)
}

//annonymous callback function
myName.forEach(function(val:string, idx:number){
    console.log(`Data at ${idx} is ${val}`)
});


//ES6 arrow function
console.log();
console.log("user arroe operator")
myName.forEach((val:string, idx:number) => console.log(`Data at ${idx} is ${val}`));




//Arrays methods of ES6
//filter(), reduce(), map()
console.log("Array Map method")
myName.map((v:string,i:number)=>console.log(`Data at ${i} is ${v}`));

console.log("Arrayyyyyy")
let newArray = new Array<string>();
newArray = myName.filter((val:string, idx:number)=> {return val.length > 12;})

newArray.forEach((val:string, idx:number)=>{console.log(val)});