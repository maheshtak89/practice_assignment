var myName;
myName = new Array();
myName.push("sanjay");
myName.push("Deepak");
myName.push("Rajat");
myName.push("Bharat");
//simple array iteration
myName.forEach(printValues);
function printValues(val, idx) {
    console.log("Data at " + idx + " is " + val);
}
//annonymous callback function
myName.forEach(function (val, idx) {
    console.log("Data at " + idx + " is " + val);
});
//ES6 arrow function
console.log();
console.log("user arroe operator");
myName.forEach(function (val, idx) { return console.log("Data at " + idx + " is " + val); });
//Arrays methods of ES6
//filter(), reduce(), map()
console.log("Array Map method");
myName.map(function (v, i) { return console.log("Data at " + i + " is " + v); });
console.log("Arrayyyyyy");
var newArray = new Array();
newArray = myName.filter(function (val, idx) { return val.length > 12; });
newArray.forEach(function (val, idx) { console.log(val); });
