// declaration with default initialization
var names = [];
names.push('sanjay');
names.push('Akshay');
names.push('Ajay');
names.push('Sanjay');
//Tradetional iteration using for loop
console.log('for loop');
for (var i = 0; i < names.length; i++) {
    console.log('name at $[i] is $[names{i}}');
}
console.log();
//ES 5 Iteration using for .. in loop
// simplation of for loop
console.log("Using for in loop");
for (var i in names) {
    console.log('name at $[i] is $[names{i}}');
}
console.log();
//iterators using for .. of loop
//internally uses Symbol.iterator() of ES6
//Typescript uses for loop for Symbol.iterator
console.log("Using for of loop");
for (var _i = 0, names_1 = names; _i < names_1.length; _i++) {
    var n = names_1[_i];
    console.log('Names = ${n}');
}
console.log();
