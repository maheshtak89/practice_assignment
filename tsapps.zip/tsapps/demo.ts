function demo(x){
    var a=10;

    if(x){
        console.log("This is : "+a);
    }
    console.log(a);
}
demo(true);
demo(false);