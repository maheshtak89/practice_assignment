function demo(x) {
    var a = 10;
    if (x) {
        console.log("This is : " + a);
    }
    console.log(x);
}
demo(true);
demo(false);
